/**
 * Just an example of interaction with Arduino via serial port, using
 * JavaSerial package (and RXTXcomm.jar, rxtxSerial.so of course).
 * It is a serial terminal (input from console to serial and serial to console)
 * It needs an Arduino sketch that interacts. 
 * 
 * @author Daniele Denaro
 *
 */

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.Vector;
import java.util.concurrent.LinkedTransferQueue;

import JavaSerial.CommReceiver;
import JavaSerial.SerialComm;


public class TestSerialConsole {

	SerialComm Comm;
	PrintStream commpr;
//	String Port="/dev/Arduino";
	String Port="/dev/ttyS0";
	int Bauds=9600;
	
	CReceiver Receiver=null;	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
       TestSerialConsole T=new TestSerialConsole();
       T.openSer();
	}
	
	public void openSer()
	{
		Vector <String> vc=SerialComm.getFreeCommName();
		for (int i=0;i<vc.size();i++) System.out.println(vc.get(i));
		System.out.println(Port+":"+SerialComm.exist(Port));
		if (Receiver==null) Receiver=new CReceiver();
		else Receiver.reset();
		Comm=SerialComm.openComm(Port, Bauds, Receiver);
		if (Comm==null) System.out.println("NOK");
		else 
		{commpr=Comm.getPrintStream();System.out.println("OK");
		 CTransmitter Ct=new CTransmitter();Ct.start();}		
	}
	
	
	class CReceiver implements CommReceiver
	{
		LinkedTransferQueue <String> buffer=new LinkedTransferQueue();
		
		public void reset(){buffer.clear();}

		@Override
		public void newByte(byte by) {}

		@Override
		public void newRecord(String rec) {
		//  buffer.add(rec);
		  System.out.print(rec);
		}	
	}
	
	class CTransmitter extends Thread
	{
		String rec;
		BufferedReader Cinp= new BufferedReader(new InputStreamReader(System.in));
		public void run()
		{
			while(true)
			{
				try {rec=Cinp.readLine();} catch (IOException e1) {e1.printStackTrace();}
				if (rec==null)
				{
					try {Thread.sleep(100);} 
				    catch (InterruptedException e) {e.printStackTrace();}
					continue;
				}
				commpr.println(rec);
			}
		}
	}
}
