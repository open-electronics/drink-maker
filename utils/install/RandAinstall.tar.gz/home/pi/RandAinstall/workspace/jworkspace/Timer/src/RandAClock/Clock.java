package RandAClock;

import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;

import com.pi4j.io.i2c.I2CBus;
import com.pi4j.io.i2c.I2CDevice;
import com.pi4j.io.i2c.I2CFactory;

/**
 * Class for RTC DS1339 management.
 * Only static methods to set RTC, to get date/time and to program restart.
 * Methods use pi4j library (and wiringPi library).
 * @author DanieleDenaro
 *
 */
public class Clock 
{
	static private int DS1339add=0x68;
	static private I2CBus I2C=null;
	static private I2CDevice timer=null;

/**
 *  Static reference to RTCDate class.<br>
 *  Fields:<br>
 *      Date.Year     (2000-2099)<br>
 *      Date.Month    (1-12)<br>
 *      Date.Day      (1-31)<br>
 *      Date.Hour     (0-23)<br>
 *      Date.Min      (0-59)<br>
 *      Date.Sec      (0-59)<br>
 *      Date.WeekDay  (1=Monday...7=Sunday)	
 */
	static public RTCDate Date=new RTCDate();
    static public RTCAlarm Alarm=new RTCAlarm();
/**
 * Set RTC with Date fields values.
 * I.e. this function uses values stored in the Date instance to write RTC registers.	
 * @return true if setting done
 */
    static public boolean setDate()  {return writeDate();}

/**
 * Set RTC with values. 
 * I.e. This function set Date values first and then sets RTC registers.     
 * @param yyyy (2000-2099)
 * @param mm   (1-12)
 * @param dd   (1-31)
 * @param hh   (0-23)
 * @param min  (0-59)
 * @return true if setting done
 */
	static public boolean setDate(int yyyy,int mm,int dd,int hh,int min)
	{
		yyyy=yyyy%100;mm=mm%13;dd=dd%32;hh=hh%24;min=min%60;
		if (mm==0) mm++;if (dd==0) dd++;
		Date.Year=yyyy;Date.Month=mm;Date.Day=dd;Date.Hour=hh;Date.Min=min;
		Date.setWeekDay();
		return setDate();
	}

/**
 * Set only RTC time	
 * @param hh  (0-23)
 * @param min (0-59)
 * @return true if setting done
 */
	static public boolean setTime(int hh,int min)
	{
		hh=hh%24;min=min%60;
		Date.Hour=hh;Date.Min=min;
	    return writeTime();
	}

/**
 * Read RTC registers into Date values	
 * @return Date reference
 */
	static public RTCDate getRTCDate()
    {
    	readDate();
    	return Date;
    }

/**
 * Read Date from RTC and return a timestamp string
 * @return String timestamp. Format yyyy-mm-dd hh:min
 */
	static public String getTimeStamp()
	{
		readDate();
		return Date.toString();
	}

/**
 * Get Date in JSON format.
 * I.e. string "[Date.Year(two digits),Date.Month,Date.Day,Date.Hour,Date.Min,WeekDay(true or false)]" 	
 * @return
 */
	static public String getJsonDate()
	{
		readDate();
		return "["+Date.toCSV()+"]";
	}

/**
 * Read Date from RTC and return only date
 * @return String : yyyy-mm-dd
 */
	static public String getDate()
	{
		String sdate="";
		readDate();
		sdate=Date.Year+"-"+Date.Month+"-"+Date.Day;
		return sdate;
	}

/**
 * Read hour,minutes,seconds  from RTC and return only time	
 * @return String : hh:min:sec
 */
	static public String getTime()
	{
		String stime="";
		readTime();
		stime=Date.Hour+":"+Date.Min+":"+Date.Sec;
		return stime;
	}

/**
 * Read seconds from RTC 	
 * @return seconds (0-59)
 */
	static public int getSec()
	{
		byte buff=readByte(0);
		Date.Sec=getBCDtoInt(buff,7);		
		return Date.Sec;
	}

/**
 * Read minutes from RTC	
 * @return minutes (0-59)
 */
	static public int getMin()
	{
		readTime();
		return Date.Min;
	}

/**
 * Read hour from RTC	
 * @return hour (0-23)
 */
	static public int getHour()
	{
        readTime();
		return Date.Hour;
	}

	
/**
 * Shutdown and programmed restart when RTC minute=min	
 * @param min (0-59)
 */
	static public void restartAt(int min) {restartAt(-1,-1,min,false);shutdw();}

/**
 * Shutdown and programmed restart when RTC hour=hh and minute=min	
 * @param hh  (0-23)
 * @param min (0-59)
 */
	static public void restartAt(int hh,int min) {restartAt(-1,hh,min,false);shutdw();}

/**
 * Shutdown and programmed restart when RTC day (of month)=dd and hour=hh and minute=min	
 * @param dd (1-31)
 * @param hh (0-23)
 * @param min(0-59)
 */
	static public void restartAt(int dd,int hh, int min) {restartAt(dd,hh,min,false);shutdw();}

/**
 * Shutdown and programmed restart when RTC day (of week)=wd and hour=hh and minute=min	
 * @param wd (1-7)
 * @param hh (0-23)
 * @param min(0-59)
 */
	static public void restartAtWeek(int wd,int hh, int min) {restartAt(wd,hh,min,true);shutdw();}

/**
 * Shutdown and restart programmed after time=dh:dmin (ex. dh=0 dmin=30 : in 30 minutes)	
 * @param dh   (0-23)
 * @param dmin (0-59)
 */
	static public void restartIn(int dh, int dmin)
	{
		readTime();
		int hh=Date.Hour+dh;
		int min=Date.Min+dmin;
		hh=hh+min/60;min=min%60;
		hh=hh%24;
		restartAt(hh,min);
		shutdw();
	}

/**
 * Set Alarm without shutdown	
 * @param hh
 * @param mm
 */
	static public void setAlarmHourMin(int hh,int mm)
	{
		setAlarm(-1,hh,mm,false);
	}

/**
 * Set Alarm without shutdown	
 * @param dd
 * @param hh
 * @param mm
 */
	static public void setAlarmDay(int dd,int hh,int mm)
	{
		setAlarm(dd,hh,mm,false);
	}

/**
 * Set Alarm without shutdown	
 * @param wd
 * @param hh
 * @param mm
 */
	static public void setAlarmWeekDay(int wd,int hh,int mm)
	{
		setAlarm(wd,hh,mm,true);
	}
	
/**
 * Set alarm without shutdown.	
 * @param dd
 * @param hh
 * @param mm
 * @param fw : false if dd=day , true if dd=weekday
 */
	static public void setAlarm(int dd,int hh,int mm,boolean fw)
	{
		restartAt(dd,hh,mm,fw);
	}

/**
 * Get alarm, i.e. what is the programmed restart.	
 * @return (No restart or Restart at: ...)
 */
	static public String getAlarm()
	{
		String ck=null;
		if (readAlarm()==null) return null;
		if (Alarm.nowakeup) return ck="No restart";
		if (Alarm.hh<0) return ck="Restart at: "+"**:"+Alarm.min;
		if (Alarm.dd<0) return ck="Restart at: "+Alarm.hh+":"+Alarm.min;
		if (Alarm.wd) return ck="Restart at: "+Alarm.hh+":"+Alarm.min+" week day "+Alarm.dd;
		else return ck="Restart at: "+Alarm.hh+":"+Alarm.min+" day "+Alarm.dd;
	}

/**
 * Get Alarm in JSON format.
 * I.e. string "["m(or w if weekday)",Alarm.dd,Alarm.hh,Alarm.min,"y (or n if no wakeup)"]"	
 * @return
 */
	static public String getJsonAlarm()
	{
		String ck=null;
		if (readAlarm()==null) return null;
		if (Alarm.nowakeup) {ck="[\"m\",0,0,0,\"n\"]";return ck;}	
		else
		{
			if (Alarm.hh<0) {ck="[\"m\",-1,-1,"+Alarm.min+",\"y\"]";return ck;}
			if (Alarm.dd<0) {ck="[\"m\",-1,"+Alarm.hh+","+Alarm.min+",\"y\"]";return ck;}
			if (Alarm.wd)   {ck="[\"w\","+Alarm.dd+","+Alarm.hh+","+Alarm.min+",\"y\"]";return ck;}
			else {ck="[\"m\","+Alarm.dd+","+Alarm.hh+","+Alarm.min+",\"y\"]";return ck;}
		}
	}

/**
 * Reset alarm. (Used at startup)	
 * @return
 */
	static public boolean resetAlarm()
	{
		byte buff[]=new byte[3];
		buff[0]=0;buff[1]=0;buff[2]=0;
		if (!writeByte(0x0E,(byte)24)) return false;
		if (!writeAlarm(buff)) return false;
		return true;
	}

/**
 * Shitch off power 	
 * @return
 */
	static public boolean powerOff()
	{
		if (!writeByte(0x0F,(byte)0)) return false;
		return writeByte(0x0E,(byte)6);
	}
	
	
/****************************************************************************/	
	
	static public class RTCDate
	{
		/** 2000 - 2099 */
		public int Year;
		/** 1 - 12 */
		public int Month;
		/** Day of month 1 - 31 */
		public int Day;
		/** Day of week 1 - 7 (1=Monday...7=Sunday)<b>Just for reading, don't set!</b>*/
		public int WeekDay;
		/** 0 - 23 */
		public int Hour;
		/** 0 - 59 */
		public int Min;
		/** 0 - 59 */
		public int Sec;
		private RTCDate(){};
		private RTCDate(int yy,int mm, int dd,int hh,int min, int sec,int wd)
		{Year=yy;Month=mm;Day=dd;WeekDay=wd;Hour=hh;Min=min;Sec=sec;}
        void setValues(int yy,int mm, int dd,int hh,int min, int sec,int wd)
		{Year=yy;Month=mm;Day=dd;WeekDay=wd;Hour=hh;Min=min;Sec=sec;}
        /** Used only to adjust Week day when Data fields externally loaded */
        public void setWeekDay()
        {
            GregorianCalendar C=new GregorianCalendar(Year,Month-1,Day);
            int fd=1-C.getFirstDayOfWeek();
//            C.roll(Calendar.DAY_OF_WEEK,-1);
            WeekDay=C.get(Calendar.DAY_OF_WEEK)+fd;
        }
        /** Format: yyyy-mm-dd hh:min */
    	public String toString()
    	{
    		String sdate="";
    		sdate=Date.Year+"-"+Date.Month+"-"+Date.Day+" "+Date.Hour+":"+Date.Min;
    		return sdate;
    	}
    	/** Format: [yy,mm,dd,hh,min] (json) */
    	public String toCSV()
    	{
    		String sdate="";
    		sdate=Date.Year-2000+","+Date.Month+","+Date.Day+","+Date.Hour+","+Date.Min+","+WeekDay;
    		return sdate;
    	}

	}
	
	static public class RTCAlarm
	{
		boolean nowakeup;
		int dd;
		int hh;
		int min;
		boolean wd;
		public void set(int d, int h, int mn ,boolean w )
		{
			dd=d;hh=h;min=mn;wd=w;
		}
	}
	

/**********************************************************************************/	

	static boolean init()
	{
		try {I2C=I2CFactory.getInstance(1);} 
		catch (IOException e) {e.printStackTrace();return false;}
		try {timer= I2C.getDevice(DS1339add);} 
		catch (IOException e) {e.printStackTrace();return false;}
		return true;
 	}
	
	static byte readByte(int add)
	{
		byte buff=0;
		if (!init()) return buff;
		try {buff=(byte)timer.read(add);}
		catch (IOException e) {e.printStackTrace();}
		return buff;
	}
	
	static boolean writeByte(int add, byte buff)
	{
		if (!init()) return false;
		try {timer.write(add,buff);} 
        catch (IOException e) {e.printStackTrace();return false;}
		return true;
	}
	
	static boolean writeAlarm(byte buff[])
	{
		if (!init()) return false;
        try {timer.write(0x0B,buff,0,3);} 
        catch (IOException e) {e.printStackTrace();return false;}
        return true;
	}
	
	static RTCAlarm readAlarm()
	{
		if (!init()) return null;
		byte buff[]=new byte[3];
        try {timer.read(0x0B,buff,0,3);} 
        catch (IOException e) {e.printStackTrace();return null;}
		if ((buff[0]==0)&(buff[1]==0)&(buff[2]==0)) Alarm.nowakeup=true; else Alarm.nowakeup=false;
		if (getBit(buff[0],7)==0) Alarm.min=getBCDtoInt(buff[0],7); else Alarm.min=-1;
		if (getBit(buff[1],7)==0) Alarm.hh=getBCDtoInt(buff[1],6); else Alarm.hh=-1;
		if (getBit(buff[2],7)==0) Alarm.dd=getBCDtoInt(buff[2],6); else Alarm.dd=-1;
		if (getBit(buff[2],6)==1) Alarm.wd=true;else Alarm.wd=false;
        return Alarm;
	}
	
	static void readDate()
	{
		if (!init()) return ;
		readTime();                           // first part reading : time
		byte buff[]=new byte[7];
		try {timer.read(3,buff, 3, 4);}       // RTC bytes from 3 to 6 (starting at position 3)
		catch (IOException e) {e.printStackTrace();}
		Date.WeekDay=getBCDtoInt(buff[3],3);  // **** *nnn  in BCD (tens units)
		Date.Day=getBCDtoInt(buff[4],6);      // **nn nnnn
		Date.Month=getBCDtoInt(buff[5],5);    // ***n nnnn
		Date.Year=getBCDtoInt(buff[6],8);     // nnnn nnnn
		Date.Year=2000+Date.Year;
	}
	
	static void readTime()
	{
		if (!init()) return;
		byte buff[]=new byte[3];
		try {timer.read(0,buff, 0, 3);}   // RTC bytes from 0 to 2 (starting at position 0)
		catch (IOException e) {e.printStackTrace();}
		Date.Sec=getBCDtoInt(buff[0],7);  // *nnn nnnn  
		Date.Min=getBCDtoInt(buff[1],7);  // *nnn nnnn
		Date.Hour=getBCDtoInt(buff[2],6); // **nn nnnn		
	}
	
	static boolean writeDate()
	{
		if (!init()) return false;
		writeTime();                       // first part writing : time
		byte buff[]=new byte[7];
		buff[3]=getInttoBCD(Date.WeekDay); // 0000 0nnn
		buff[4]=getInttoBCD(Date.Day);     // 00nn nnnn
		buff[5]=getInttoBCD(Date.Month);   // 000n nnnn
		int Y=Date.Year%100;
		buff[6]=getInttoBCD(Y);            // nnnn nnnn
        try {timer.write(3,buff,3,4);}     // write RTC bytes from 3 to 6 (starting at position 3)
        catch (IOException e) {e.printStackTrace();return false;}
        return true;
	}
	
	static boolean writeTime()
	{
		if (!init()) return false;
		byte buff[]=new byte[3];
		buff[0]=0;                         // 0000 0000  (seconds)
		buff[1]=getInttoBCD(Date.Min);     // 0nnn nnnn
		buff[2]=getInttoBCD(Date.Hour);    // 0nnn nnnn
        try {timer.write(0,buff,0,3);}     // write RTC bytes from 0 to 2 (starting at position 0)
        catch (IOException e) {e.printStackTrace();return false;}
        return true;
	}
	
	
/**
 * Set RTC Alarm. If dd=-1 no match day just hour and min. If hh= -1 no match hour just min
 * @param dd
 * @param hh
 * @param min
 * @param wd
 * @return
 */
	static boolean restartAt(int dd, int hh, int min,boolean wd)
	{
		Alarm.set(dd, hh, min, wd);
		byte buff[]=new byte[3];
		buff[0]=0;buff[1]=(byte)0x80;buff[2]=(byte)0x80; // bit 7 on (no match for default for hour and day)
		if (dd+hh+min==0) 
			{Alarm.nowakeup=true; buff[1]=0;buff[2]=0; 
			 if (writeAlarm(buff)) return true; else return false;} // buff all 0 : never match
	    Alarm.nowakeup=false;
		if (Alarm.dd>0)                                       // buff[2] bit 7 off (0) (match day)
		{
			if (!Alarm.wd)
			{
			  Alarm.dd=Alarm.dd%32; if (Alarm.dd==0) Alarm.dd++;
			  buff[2]=getInttoBCD(Alarm.dd);                  // buff[2] bit 6 off (0) (month day)
			}
			else
			{
	          Alarm.dd=Alarm.dd%8; if (Alarm.dd==0) Alarm.dd++;
	          buff[2]=(byte)(0x40+Alarm.dd);                   // buff[2] bit 6 on (1) (week day)
			}
		}
		if (Alarm.hh>=0)                                       // buff[1] bit 7 off (0) (match hour)
		{
			Alarm.hh=Alarm.hh%24;
			buff[1]=getInttoBCD(Alarm.hh);
		}
		Alarm.min=Math.abs(Alarm.min%60);
		buff[0]=getInttoBCD(Alarm.min);                        // buff[0] bit 7 always off (match min)
		if (writeAlarm(buff)) return true;else return false;
	}
	
	static void shutdw()
	{
		Runtime rt=Runtime.getRuntime();
		try {rt.exec("sudo shutdown -h now");} 
		catch (IOException e) {e.printStackTrace();}
	}

/**
 * Transorm BCD format to Integer	
 * @param buff
 * @param len : number of bits used
 * @return
 */
	static int getBCDtoInt(byte buff,int len)
	{
	    buff=(byte)(buff&(0xFF>>(8-len)));
	    if (len<=4) return buff;
	   	int b0=buff&0xF;
	   	int b1=(buff>>4);
	   	return b1*10+b0;
	}

	static byte getInttoBCD(int buff)
	{
	    byte b=(byte)((buff/10)<<4);
	    b=(byte)(b+(buff%10));
	    return b;
	}

	
	static int getBit(byte b,int n)	{return (b>>n)&1;}
		
    static byte setBit(byte b,int n)
    {
    	byte bb=b;
    	byte mask=(byte)(1<<n);
    	return (byte)(bb|mask);
    }
    
    static byte resetBit(byte b,int n)
    {
    	byte bb=b;
    	byte mask=(byte)~(1<<n);
    	return (byte)(bb&mask);
    }

}
