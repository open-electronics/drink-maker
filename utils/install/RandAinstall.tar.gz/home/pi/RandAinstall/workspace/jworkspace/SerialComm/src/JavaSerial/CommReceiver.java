package JavaSerial;

/**
 * Interface implemented by an object provided to a openComm method.
 * These two callback functions are used by the hidden receiver thread 
 * when data are received.
 * @author D.Denaro
 */
public  interface CommReceiver 
{
	public void newByte(byte by);
	public void newRecord(String rec);
}
