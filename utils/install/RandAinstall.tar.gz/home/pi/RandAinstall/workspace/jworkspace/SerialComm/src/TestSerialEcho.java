import java.io.PrintStream;

import JavaSerial.SerialComm;
import JavaSerial.CommReceiver;

/**
 * Just an example of interaction with Arduino via serial port, using
 * JavaSerial package (and RXTXcomm.jar, rxtxSerial.so of course).
 * It is an echo of data sent from Arduino. But also a log is done on
 * Linux console.
 * 
 * @author Daniele Denaro
 *
 */
public class TestSerialEcho implements CommReceiver
{

	SerialComm Comm;
	PrintStream commpr;
	String Port="/dev/ttyS0";
	int Bauds=9600;
	boolean frun=true;
	
	
	/**
	 * @param args
	 */
	public static void main(String[] args) {
        TestSerialEcho Test=new TestSerialEcho();
        Test.openSer();
        Test.cycle();
	}
	
	// forever cycle do nothing. Just to stay running and receive callback
	// function. Cycle exits when a string "$$$END" is received.
	void cycle()
	{
		while(frun) sleep(100);
	}
	
	// Open serial
	public void openSer()
	{
		Comm=SerialComm.openComm(Port, Bauds, this);
		if (Comm==null) {System.out.println("NOK");System.exit(-1);}
		else {commpr=Comm.getPrintStream();System.out.println("OK");}		
	}



	//not used
	public void newByte(byte by) {
		
	}


	//do echo
	//but if string contain $$$END stops cycle and exit
	public void newRecord(String rec) {
        if (rec.compareToIgnoreCase("$$$END")==0) frun=false;
        else
        {
 //       	commpr.print(rec);  //not echo
        	System.out.print(rec);
        }
	}
	
	void sleep(int t)
	{
		try {Thread.sleep(100);} 
		catch (InterruptedException e) {e.printStackTrace();}
	}

}
