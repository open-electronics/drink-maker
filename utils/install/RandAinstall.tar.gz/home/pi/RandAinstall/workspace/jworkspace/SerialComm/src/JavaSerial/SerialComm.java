/* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
* This program is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
* GNU General Public License for more details.
*/


package JavaSerial;

import gnu.io.*;

import java.util.concurrent.*;
import java.io.FileDescriptor;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;

import javax.swing.JOptionPane;

import java.util.*;
/**
 * Simplified management of RXTXComm.jar library
 * It also need rxtxSerial.so (rxtxSerial.ddl on windows) 
 * Put this library in /usr/lib/jni (if not jet present)
 * (Arduino IDE install automatically this library)
 * Static methods:<br>
 * - Open port (see further on)<br>
 * - Get list of available ports<br>
 * - Verify if port exists.<br>
 * - Show status (message dialog)<br>
 * <br>
 * Open port<br>
 * This static method opens serial port by name, uses a pointer to an 
 * object implementing an interface CommReceiver and returns an object
 * SerialComm.
 * SerialComm has methods to get a PrintStream object whereto write 
 * outgoing messages, and to get features.
 * Open port method also starts a receiver thread that automatically receives 
 * data and calls methods defined in CommReceiver interface (callback functions). 
 * Object CommReceiver, provided to open port method, must implements these
 * two methods:
 * - newRecord(String rec) :  this is called by receiver thread when a record 
 * (string terminated by linefeed) is arrived and it is supplied as argument.<br>
 * - newByte(byte by) : this function is called at every byte received<br>
 * So you can implement communication just using PrintStream given by SerialComm
 * object (returned by open method) and defining one of this two methods in 
 * your class implementing CommReceiver interface and supplied to open method.<br>
 * Serial port will be closed using method closeComm() of SerialComm object. 
 * 
 * @author Daniele Denaro
 */
public class SerialComm
{
	public static final int COMM_INUSE=-1; 
	public static final int COMM_UNKNOWN=-2;
	public static final int COMM_NOSER=-3;
	public static final int COMM_UNOP=-4;
	public static final int COMM_NOOUT=-5;
	public static final int COMM_NOREADER=-6;
	public static final int COMM_OK=0;
	
	public static boolean errorShow=false;
	
	private static class Error
	{
		static int cod;
		static String mess;
	}
	
	private SerialPort comm;
	private SerialReader sreader;
	private PrintStream prs;
	
	
	/**
	 * Private constructor. Not direct instance (used by openComm()).
	 * But object has several usable methods 
	 * @param c
	 * @param sr
	 * @param pr
	 */
	private SerialComm(SerialPort c,SerialReader sr,PrintStream pr)
	{
		comm=c;
		sreader=sr;
		prs=pr;
	}

	
	public SerialPort getPort(){return comm;}
	public PrintStream getPrintStream(){return prs;}
	public int getBauds(){return comm.getBaudRate();}
	public int getBits(){return comm.getDataBits();}
	public int getParity(){return comm.getParity();}
	public int getStopbits(){return comm.getStopBits();}
	
	public int getErrorCode(){return SerialComm.Error.cod;}
	public String getErrorMess(){return SerialComm.Error.mess;}
	
	/**
	 * Close Serial Port
	 */
	public void closeComm()
	{
		prs.flush();
		prs.close();
		sreader.closeThread();
		comm.close();
	}

/**
 * Returns array of port identifiers available	
 * @return
 */
  static public Vector<CommPortIdentifier> getFreeComm()
  {
      CommPortIdentifier commId=null;
      Vector<CommPortIdentifier> vcomm=new Vector();
      Enumeration<CommPortIdentifier> comms=CommPortIdentifier.getPortIdentifiers();
      while(comms.hasMoreElements())
      {
    	  commId=comms.nextElement();
          if (commId.getPortType()==CommPortIdentifier.PORT_SERIAL)
          if (!commId.isCurrentlyOwned()) vcomm.add(commId);
       }
	   return vcomm;
  }

/**
 * Returns array of port names available	
 * @return
 */
  
  static public Vector<String> getFreeCommName()
  {
       CommPortIdentifier commId=null;
       Vector<String> svcomm=new Vector();
       Vector<CommPortIdentifier> vcomm=getFreeComm();
       for (int i=0;i<vcomm.size();i++) {svcomm.add(vcomm.get(i).getName());}
       return svcomm;
  }

 /**
  * Verifies if port exists   
  * @param name
  * @return
  */
   static public boolean exist(String name)
   {
       CommPortIdentifier commId=null;
       try{commId=CommPortIdentifier.getPortIdentifier(name);}
       catch(NoSuchPortException e){return false;}
       return true;
   }


 /**
  * Principal method; it opens serial port and returns an object SerialComm.
  * This method also starts a thread that continously gets data from serial port
  * and runs two callback function defined in CommReceiver interface.<br>
  * - newRecord(String rec) : when record is received (terminated with lf or lf+cr)<br>
  * - newByte(byte by) : for each byte received<br>
  * So, an object that implements CommReceiver interface has to be supplied.
  * @param name		serial name
  * @param bauds	bps
  * @param receiver	CommReceiver object
  * @param databits Byte format
  * @param stopbits Byte format
  * @param parity   Byte format
  * @return			SerialComm object
  */
   static public SerialComm openComm(String name,int bauds,CommReceiver receiver,int databits,int stopbits,int parity)
   {
       CommPort comm=null;
       SerialPort scomm=null;
       CommPortIdentifier commId=null;
       PrintStream pr=null;
       SerialComm sc=null;
       try{commId=CommPortIdentifier.getPortIdentifier(name);}
       catch(NoSuchPortException e){ErrMess(COMM_UNKNOWN,name);return null;}
       try {comm=commId.open(Thread.currentThread().getClass().getName(),2000);}
       catch(PortInUseException ex) {ErrMess(COMM_INUSE,name);return null;}
       if (!(comm instanceof SerialPort)){ErrMess(COMM_NOSER,name);return null;}
       scomm=(SerialPort)comm;
       try {scomm.setSerialPortParams(bauds,databits,stopbits,parity);} 
       catch (UnsupportedCommOperationException e)
             {scomm.close();ErrMess(COMM_UNOP,name);return null;}
       try {pr=new PrintStream(scomm.getOutputStream());}
       catch (IOException e)
             {scomm.close();ErrMess(COMM_NOOUT,e.getMessage());return null;}        
       SerialReader reader=new SerialReader(scomm,receiver);
       if (reader==null){ErrMess(COMM_NOREADER,name);return null;}
       reader.start(); 
       sc=new SerialComm(scomm,reader,pr);
       ErrMess(COMM_OK,name);
       return sc;
   }

   /**
    * Like previous but with standard format (8 bits, 1 stop bit,no parity) 
    * @param name		serial name
    * @param bauds	    bps
    * @param receiver	CommReceiver object
    * @return			SerialComm object
    */   
   static public SerialComm openComm(String name,int bauds,CommReceiver receiver)
   {
	   return openComm(name,bauds,receiver,SerialPort.DATABITS_8,SerialPort.STOPBITS_1,SerialPort.PARITY_NONE);
   }
   

   private static class SerialReader extends Thread
   {
	   CommReceiver receiver;
       SerialPort comm=null;
       InputStream in;
       int by,oldby;
       byte[] buffer = new byte[4096];
       boolean stop=false;
 
       SerialReader(SerialPort comm,CommReceiver receiver)
       {
           super();
           this.comm=comm;
           try{comm.enableReceiveTimeout(500);}
                                 catch(Exception e){e.printStackTrace();}
           try {in=comm.getInputStream();}
                                 catch(IOException e){e.printStackTrace();}
           this.receiver=receiver;
       }

       public void closeThread(){stop=true;}

       public void run()
       {
    	   int n=0;
            try
            {
              while ( !stop )
              {
                by=this.in.read();
                if(by<0) {continue;}
                receiver.newByte((byte)by);
                buffer[n]=(byte)by;
                if ((n==0)&(by=='\n')) continue;
                if (by=='\r') oldby=by; 
                if ((by=='\n')&(oldby=='\r')) 
                {String rec=new String(buffer,0,n+1);receiver.newRecord(rec);n=0;oldby=0;continue;}
                n++;
                if (n>=buffer.length-2) 
                {String rec=new String(buffer,0,n+1);receiver.newRecord(rec);n=0;oldby=0;continue;}	
              }
              in.close();
            }
            catch ( IOException e ){ e.printStackTrace();}
       }
   }

   static private void ErrMess(int err,String txt)
   {
	  Error.cod=err; 
	  switch(err)
	  {
	    case COMM_UNKNOWN: Error.mess=txt+" port doesn't exist !";break;
	    case COMM_INUSE: Error.mess=txt+" port already in use. Close that application!";break;
	    case COMM_NOSER: Error.mess=txt+" not serial port!";break;
	    case COMM_UNOP: Error.mess=txt;break;
	    case COMM_NOOUT: Error.mess=txt;break;
	    case COMM_NOREADER: Error.mess="Error on creating reader thread";break;
	    case COMM_OK: Error.mess=txt+" created!";break;
	  }
      if (errorShow) ShowStatus();
   }

/**
 * Shows error (if any in port opening) in a message dialog window.    
 */
   static public void ShowStatus()
   {JOptionPane.showMessageDialog(null, Error.mess);}


}
